/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

import java.util.ArrayList;

/**
 *
 * @author Innovation Computers
 */
public class BCP {
    
    public int ID;
    public String estado;
    public int contador;
    public int tamañoMemoria;
    public ArrayList<String> registros = new ArrayList<String>();

    public BCP(int ID, String estado, int tamañoMemoria) {
        this.ID = ID;
        this.estado = estado;
        this.contador = contador;
        this.tamañoMemoria = tamañoMemoria;
    }
       
    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }

    public int getTamañoMemoria() {
        return tamañoMemoria;
    }

    public void setTamañoMemoria(int tamañoMemoria) {
        this.tamañoMemoria = tamañoMemoria;
    }
    
        @Override
    public String toString() {
        return  "ID=" + ID + ", estado=" + estado +  " tamaño memoria=" + tamañoMemoria + ", registros = " + registros + '\n';
    }
    
    
    
}
