package javaapplication1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
/**
 *
 * @author Innovation Computers
 */
public class proceso {


    String lineaActual;
     
    public BCP getBcp() {
        return bcp;
    }

    public void setBcp(BCP bcp) {
        this.bcp = bcp;
    }
    protected int id;
    protected ArrayList<String> lineas;
    protected BCP bcp;
    
         

    public proceso(int id) {
        this.id = id;
        this.lineas = new ArrayList<>();
        this.bcp = new BCP(this.id, "Running", lineas.size() ); 
    }

    public void leerArchivoASM(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                lineas.add(linea.trim()); 
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
        
    }

    public int getId() {
        return id;
    }

    public ArrayList<String> getTextos() {
        return lineas;
    }


  }


   