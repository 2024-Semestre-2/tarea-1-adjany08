/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

import static java.lang.Math.random;
import java.util.ArrayList;
import java.util.Random;

public class memoria {

    public memoria() {
    }
    
    protected String[] espacio = new String[100];

    public String[] getEspacio() {
        return espacio;
    }
    
    public int generarLocation(){
        
        Random random = new Random();
        int inicio = 20;
        int fin = 100;
        
        int numeroAleatorio = random.nextInt(fin-inicio+1) + inicio;
        
        return numeroAleatorio;
        
    }
    
    
    public void asignarMemoria(ArrayList<String> arreglo, int proceso) {
        
        int espacioAsignado = generarLocation();
        while(!(arreglo.size() < (81) && (espacioAsignado + arreglo.size()) <= 80)){
        
            espacioAsignado = generarLocation();
        }
                                   
        for (int i = 0; i < arreglo.size(); i++) {
        espacio[espacioAsignado] = "proceso #"+proceso+" "+arreglo.get(i).toString();
        espacioAsignado++;
               
        }

        
    }
    
}
